=== Current Year Shortcode by Considera ===
Contributors: samuraider 
Tags: year, shortcode, considera
Requires at least: 4.7
Tested up to: 6.2
Stable tag: 0.1
Requires PHP: 7.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html
Makes available a shortcode [year] that can be used to display the current year - "[year] is the shortcode available"